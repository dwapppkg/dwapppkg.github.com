The default directory to place BIRT script lib files.
